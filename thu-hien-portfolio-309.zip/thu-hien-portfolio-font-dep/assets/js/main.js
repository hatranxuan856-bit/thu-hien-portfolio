// Menu mobile
    const menuToggle = document.getElementById('menuToggle');
    const navLinks = document.getElementById('navLinks');
    menuToggle.addEventListener('click', () => {
      const opened = navLinks.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', String(opened));
      menuToggle.textContent = opened ? '×' : '☰';
      document.body.classList.toggle('menu-open', opened);
    });
    navLinks.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
      menuToggle.textContent = '☰';
      document.body.classList.remove('menu-open');
    }));

    // Bộ lọc dự án
    const filterButtons = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');
    filterButtons.forEach(button => button.addEventListener('click', () => {
      filterButtons.forEach(item => item.classList.remove('active'));
      button.classList.add('active');
      const filter = button.dataset.filter;
      projectCards.forEach(card => {
        const categories = card.dataset.category.split(' ');
        card.hidden = filter !== 'all' && !categories.includes(filter);
      });
    }));

    // Modal xem chi tiết dự án
    const modal = document.getElementById('projectModal');
    const closeModal = () => modal.classList.remove('open');
    document.querySelectorAll('.view-project').forEach(button => {
      button.addEventListener('click', () => {
        const card = button.closest('.project-card');
        document.getElementById('modalTitle').textContent = card.dataset.title;
        document.getElementById('modalClient').textContent = card.dataset.client;
        document.getElementById('modalDescription').textContent = card.dataset.description;
        document.getElementById('modalWork').textContent = card.dataset.work;
        const result = card.dataset.result.trim();
        const resultHeading = document.getElementById('modalResultHeading');
        const resultText = document.getElementById('modalResult');
        resultHeading.hidden = !result;
        resultText.hidden = !result;
        resultText.textContent = result;
        const channelHeading = document.getElementById('modalChannelsHeading');
        const channelList = document.getElementById('modalChannels');
        const channels = JSON.parse(card.dataset.channels || '[]');
        channelList.replaceChildren();
        channels.forEach(channel => {
          const link = document.createElement('a');
          const name = document.createElement('strong');
          const stats = document.createElement('span');
          link.className = 'modal-channel';
          link.href = channel.url;
          link.target = '_blank';
          link.rel = 'noopener noreferrer';
          name.textContent = channel.name;
          stats.textContent = channel.metrics || [channel.country, channel.subscribers, channel.videos, channel.views]
            .filter(Boolean)
            .join(' · ');
          link.append(name, stats);
          channelList.append(link);
        });
        channelHeading.hidden = channels.length === 0;
        channelList.hidden = channels.length === 0;
        const gallery = document.getElementById('modalGallery');
        const imagePaths = (card.dataset.images || '').split('|').filter(Boolean);
        const imageCaptions = (card.dataset.imageCaptions || '').split('|');
        gallery.replaceChildren();
        gallery.classList.toggle('three-up', imagePaths.length === 3);
        imagePaths.forEach((imagePath, index) => {
          const figure = document.createElement('figure');
          const image = document.createElement('img');
          image.src = imagePath;
          image.alt = imageCaptions[index] || `Hình ảnh ${index + 1} của dự án ${card.dataset.title}`;
          image.loading = 'lazy';
          figure.append(image);
          if (imageCaptions[index]) {
            const caption = document.createElement('figcaption');
            caption.textContent = imageCaptions[index];
            figure.append(caption);
          }
          gallery.append(figure);
        });
        if (card.dataset.galleryCaption) {
          const caption = document.createElement('p');
          caption.className = 'modal-gallery-caption';
          caption.textContent = card.dataset.galleryCaption;
          gallery.append(caption);
        }
        gallery.hidden = imagePaths.length === 0;
        const tags = document.getElementById('modalTags');
        tags.replaceChildren();
        card.dataset.tags.split(',').forEach(tag => {
          const el = document.createElement('span');
          el.className = 'tag';
          el.textContent = tag.trim();
          tags.appendChild(el);
        });
        modal.classList.add('open');
        document.getElementById('modalClose').focus();
      });
    });
    document.getElementById('modalClose').addEventListener('click', closeModal);
    modal.addEventListener('click', event => { if (event.target === modal) closeModal(); });
    document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });

    // Sao chép email
    document.getElementById('copyEmail').addEventListener('click', async () => {
      const email = 'hien57177@gmail.com';
      try {
        await navigator.clipboard.writeText(email);
        document.getElementById('copyEmail').textContent = 'Đã sao chép ✓';
      } catch {
        window.location.href = 'mailto:' + email;
      }
    });

    // Năm hiện tại
    document.getElementById('year').textContent = new Date().getFullYear();

    // Hiệu ứng xuất hiện khi cuộn
    const revealItems = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.12 });
      revealItems.forEach(item => observer.observe(item));
    } else {
      revealItems.forEach(item => item.classList.add('visible'));
    }

    // Đánh dấu mục menu đang xem
    const sections = document.querySelectorAll('main section[id]');
    if ('IntersectionObserver' in window) {
      const sectionObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            navLinks.querySelectorAll('a').forEach(link => {
              link.classList.toggle('active', link.getAttribute('href') === '#' + entry.target.id);
            });
          }
        });
      }, { rootMargin: '-35% 0px -55% 0px' });
      sections.forEach(section => sectionObserver.observe(section));
    }
